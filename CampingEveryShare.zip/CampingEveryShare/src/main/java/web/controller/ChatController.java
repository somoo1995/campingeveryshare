package web.controller;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/chat")
public class ChatController {

    @MessageMapping("/message") // 클라이언트가 /app/message로 메시지를 보내면 이 메서드가 호출됨
    @SendTo("/topic/messages") // 반환 값은 /topic/messages로 브로드캐스트됨
    public String processMessage(String message) {
        return message; // 클라이언트로부터 받은 메시지를 그대로 반환
    }
    
    @GetMapping
    public String showChatPage() {
        return "chat"; // chat.jsp 뷰로 이동
    }
}
