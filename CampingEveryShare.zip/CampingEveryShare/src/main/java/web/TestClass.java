package web;

import web.dto.Msg;

public class TestClass {
public static void main(String[] args) {
	Msg msg = new Msg();
	System.out.println(msg);
}
}
