package a.b.web;

public class SeonggwonTest {
	private String 성권;
	private String 성권2;
}
