package a.b.web;

public class DainTest {
	private String dain;

}
